//
//  BleScanPrinterTableViewController.swift
//  GoApp
//
//  Created by ＵＳＥＲ on 9/8/16.
//  Copyright © 2016 godexintl. All rights reserved.
//

import UIKit
import CoreBluetooth
import GoDEX

class BleScanPrinterTableViewController: UITableViewController , CBCentralManagerDelegate , CBPeripheralDelegate{

    @IBOutlet weak var bbRefresh: UIBarButtonItem!
    
    static let shareBLE = BleScanPrinterTableViewController()
    
    fileprivate var appDelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    var btCentralManager: CBCentralManager!
    var btPeripherals: [CBPeripheral] = []
    var selectedPeripheral: CBPeripheral?
    var btRSSIs: [NSNumber] = []
    var btConnectable: [Int] = []
     var cs_string = NSLocalizedString("Connected Status", comment: "")
    
    fileprivate var timer: Timer?
    fileprivate var setting = false
    fileprivate var printReadString = ""
    
    //多國語系
    let OK = NSLocalizedString("OK", comment: "")
    let ConnectedSuccess = NSLocalizedString("Connected Success", comment: "")
    
        @IBAction func actionRefresh(_ sender: AnyObject) {
            bbRefresh.isEnabled = false
            spinner.startAnimating()
            btConnectable.removeAll()
            btPeripherals.removeAll()
            btRSSIs.removeAll()

            tableView.register(UINib(nibName: "PeripheralCell", bundle: nil), forCellReuseIdentifier: "PeripheralCell")

            Timer.scheduledTimer(timeInterval: 5, target: self, selector: #selector(self.stopScan), userInfo: nil, repeats: false)
            btCentralManager.scanForPeripherals(withServices: nil, options: nil)
        }
    @IBOutlet weak var bbrefresh: UIBarButtonItem!
    @IBOutlet var spinner: UIActivityIndicatorView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        spinner.hidesWhenStopped = true
        spinner.transform = CGAffineTransform(scaleX: 2, y: 2)
        spinner.style = .gray
        spinner.center = view.center
        spinner.tag = 1
        view.addSubview(spinner)
        
        btCentralManager = CBCentralManager(delegate: self, queue: nil)
        tableView.register(UINib(nibName: "PeripheralCell", bundle: nil), forCellReuseIdentifier: "PeripheralCell")
        
        btCentralManager.delegate = self
        
        if selectedPeripheral != nil {
            btCentralManager.cancelPeripheralConnection(selectedPeripheral!)
        }
        spinner.startAnimating()
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        
        bbRefresh.isEnabled = false
        btConnectable.removeAll()
        btPeripherals.removeAll()
        btRSSIs.removeAll()
        
        tableView.register(UINib(nibName: "PeripheralCell", bundle: nil), forCellReuseIdentifier: "PeripheralCell")
        
        Timer.scheduledTimer(timeInterval: 5, target: self, selector: #selector(self.stopScan), userInfo: nil, repeats: false)
        btCentralManager.scanForPeripherals(withServices: nil, options: nil)
    }
    
        override func viewWillAppear(_ animated: Bool) {
            NotificationCenter.default.addObserver(self, selector: #selector(self.BLEread), name: NSNotification.Name(rawValue: "BLEreadData"), object: nil)
        }
    
        //讀取~b內容
    @objc func BLEread() {
            let string = appDelegate.godex.getBLEString()
            printReadString += string
            print("read =",printReadString)
//            guard findPrinterType(printReadString) else {
//                return
//            }
    
            if timer != nil {
                timer?.invalidate()
                timer = nil
            }
    
            spinner.stopAnimating()
        }
    
        override func viewWillDisappear(_ animated: Bool) {
            NotificationCenter.default.removeObserver(self)
        }
    
    @objc func stopScan() {
        btCentralManager.stopScan()
        bbRefresh.isEnabled = true
        tableView.reloadData()
        spinner.stopAnimating()
    }
    
    //    override func didReceiveMemoryWarning() {
    //        super.didReceiveMemoryWarning()
    //        // Dispose of any resources that can be recreated.
    //    }
    //
    //    // MARK: TableView Delegate
    //
        override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell: PeripheralCell = tableView.dequeueReusableCell(withIdentifier: "PeripheralCell") as! PeripheralCell
            //print("__FUNCTION__ indexpath = \(indexPath) aaa \(indexPath.row)")
    
            //cell.lbConntable.text = btConnectable[indexPath.row].description
            if btPeripherals[indexPath.row].name == nil
            {
                cell.lbName.text = "unknow device"
            }
            else
            {
                cell.lbName.text = btPeripherals[indexPath.row].name
            }
    
            if (btRSSIs[indexPath.row].int32Value > -20 || btRSSIs[indexPath.row].int32Value < -99 )
            {
                cell.lbRSSI.text = "??? dbm"
            }
            else
            {
                cell.lbRSSI.text = btRSSIs[indexPath.row].description + " dbm"
            }
    
            cell.lbUUID.text = btPeripherals[indexPath.row].identifier.uuidString
            return cell
    
        }
    
        override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

            selectedPeripheral = btPeripherals[indexPath.row]
            appDelegate.godex.openport(BLEcentralManger: self.btCentralManager, BLEperipheral: selectedPeripheral!)

            NotificationCenter.default.addObserver(self, selector: #selector(BLEconnectSuccese), name: NSNotification.Name(rawValue: "BLEDidConnect"), object: nil)

        }

        func BLEconnect(_ notification: Notification){
            //self.appDelegate.currentConnectStatus = true
            //self.appDelegate.godex.connectType = GoDEX.ConnectType.ble

            //self.appDelegate.godex.sendCommand(Command: "~b")

            //BLEconnectSuccese()
        }

    @objc func BLEconnectSuccese() {

            let alertController = UIAlertController(title: self.cs_string, message: ConnectedSuccess, preferredStyle: .alert)
            let cancel = UIAlertAction(title: OK, style: .cancel, handler: { (action) in
                self.appDelegate.currentConnectStatus = true
                _ = self.navigationController?.popToRootViewController(animated: true)
            })

            alertController.addAction(cancel)
            self.present(alertController, animated: true, completion: nil)
    
            
            
        }
    
        override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 100
        }
    
        override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return btPeripherals.count
        }
    
        override func numberOfSections(in tableView: UITableView) -> Int {
            return 1
        }
    
    
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .poweredOn:
            print("Power On")
        case .poweredOff:
            print("Power Off")
        case .resetting:
            print("Resetting")
        case .unauthorized:
            print("Unauthorized")
        case .unknown:
            print("Unknown")
        case .unsupported:
            print("Unsupported")
        }
    }
    
    
        func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber)
        {
                let temp = btPeripherals.filter
                {
                    (pl) -> Bool in
                    return pl.identifier.uuidString == peripheral.identifier.uuidString
                }
    
                if temp.count == 0
                {
//                    print("uuu1 \(RSSI)")
                    btPeripherals.append(peripheral)
                    btRSSIs.append(RSSI)
                    btConnectable.append(Int((advertisementData[CBAdvertisementDataIsConnectable]! as AnyObject).description)!)
                }
        }
    
        // MARK: Timer
    
        fileprivate func timerStart() {
            timer = Timer(timeInterval: 30, target: self, selector: #selector(self.timeout), userInfo: nil, repeats: true)
        }
    
        @objc fileprivate func timeout() {
            spinner.stopAnimating()
            if timer != nil {
                timer?.invalidate()
                timer = nil
            }
            appDelegate.currentConnectStatus = false
        }
    
    //    fileprivate func findPrinterType(_ read: String) -> Bool {
    //        guard read.range(of: "F/W") != nil else {
    //            return false
    //        }
    //
    //        let firstSplit = read.components(separatedBy: "\n")
    //        let secondSplit = firstSplit[1].components(separatedBy: " ")
    //
    //        for godexPrinter in appDelegate.godexPrinters {
    //
    //            guard godexPrinter.name == secondSplit[2] else {
    //                continue
    //            }
    //            if godexPrinter.resolution == "203" {
    //                PrinterData.sharePrinterData.dpi = "200"
    //            } else {
    //                PrinterData.sharePrinterData.dpi = godexPrinter.resolution
    //            }
    //
    //            PrinterData.sharePrinterData.darknessRange = godexPrinter.darknessDefault.components(separatedBy: ",")
    //            PrinterData.sharePrinterData.darkness = godexPrinter.darkness
    //
    //            PrinterData.sharePrinterData.speedRange = godexPrinter.speedDefault.components(separatedBy: ",")
    //            PrinterData.sharePrinterData.speed = godexPrinter.speed
    //        }
    //
    //        setting = true
    //
    //        let width = PrinterData.sharePrinterData.labelWidth
    //        let height = PrinterData.sharePrinterData.labelHeight
    //        let top = PrinterData.sharePrinterData.labelTop
    //        let dark = PrinterData.sharePrinterData.darkness
    //        let speed = PrinterData.sharePrinterData.speed
    //        appDelegate.godex.plainPaperModel(width: width, height: height, top: top, dark: dark, speed: speed)
    //
    //        return true
    //    }
}
