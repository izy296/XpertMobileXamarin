//
//  PrinterParser.swift
//  GoApp
//
//  Created by Ming on 2015/11/4.
//  Copyright © 2015年 godexintl. All rights reserved.
//

import UIKit
import GoDEX

struct GodexPrintData {
    var name = ""
    var resolution = ""
    var darkness = ""
    var darknessDefault = ""
    var speed = ""
    var speedDefault = ""
}

class GoDexPrinterDatabaseParser: NSObject, XMLParserDelegate {
    
    fileprivate var godexPrinters = [GodexPrintData]()
    fileprivate var godexPrinter: GodexPrintData! = GodexPrintData()
    fileprivate var element = ""
    
    func parserXMLFile() -> [GodexPrintData] {
        let xmlPath: URL = Bundle.main.url(forResource: "PrinterModel", withExtension: "xml")!
        let parser: XMLParser = XMLParser(contentsOf: xmlPath)!
        
        parser.delegate = self
        parser.parse()
        
        return godexPrinters
    }
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String]) {
        element = elementName
        
        guard element == "PrinterModel" else {
            return
        }
        
        if let name = attributeDict["ID"] {
            godexPrinter.name = name
        }
    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        switch element {
        case "Resolution":
            godexPrinter.resolution = string
        case "Darkness":
            godexPrinter.darkness = string
        case "DarknessDefault":
            godexPrinter.darknessDefault = string
        case "Speed":
            godexPrinter.speed = string
        case "SpeedDefault":
            godexPrinter.speedDefault = string
        default:
            break
        }
    }
    
//    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
//        if elementName == "PrinterModel" {
//            godexPrinters.append(godexPrinter)
//        }
//        
//        element = ""
//    }
}
