//
//  PeripheralCell.swift
//  Godex SDK Project
//
//  Created by ＵＳＥＲ on 2018/9/13.
//  Copyright © 2018 Verbal. All rights reserved.
//

import Foundation
import UIKit

class PeripheralCell: UITableViewCell {
    
    @IBOutlet weak var lbUUID: UILabel!
    @IBOutlet weak var lbRSSI: UILabel!
    @IBOutlet weak var lbConntable: UILabel!
    @IBOutlet weak var lbName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
