//
//  ViewController.swift
//  Godex SDK Project
//
//  Created by ＵＳＥＲ on 8/8/17.
//  Copyright © 2017 Verbal. All rights reserved.
//

import UIKit
import GoDEX

//    var FontButton[UIButton] = [ Font1Button]

var cs_string = NSLocalizedString("Connected Status", comment: "")
var BLEdisconnect_string = NSLocalizedString("BLE Disconnect", comment: "")
let OK = NSLocalizedString("OK", comment: "")

class ViewController: UIViewController {
    
    @IBOutlet var Font1Button: UIButton!
     @IBOutlet var Font2Button: UIButton!
     @IBOutlet var Font3Button: UIButton!
     @IBOutlet var Font4Button: UIButton!
    @IBOutlet var ImageButton: UIButton!
    
    @IBOutlet var BarCode1Button: UIButton!
    @IBOutlet var BarCode2Button: UIButton!
    @IBOutlet var BarCode3Button: UIButton!
    @IBOutlet var BarCode4Button: UIButton!
    @IBOutlet var BarCode5Button: UIButton!
    @IBOutlet var BarCode6Button: UIButton!
    @IBOutlet var BarCode7Button: UIButton!
    
    @IBOutlet weak var outputMes: UITextView!
    @IBOutlet weak var inputMes: UITextField!
    
    fileprivate var appDelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    

    
    @IBOutlet var WiFiConnectButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        Font1Button.isHidden = true
        Font2Button.isHidden = true
        Font3Button.isHidden = true
        Font4Button.isHidden = true
        ImageButton.isHidden = true
        
        BarCode1Button.isHidden = true
        BarCode2Button.isHidden = true
        BarCode3Button.isHidden = true
        BarCode4Button.isHidden = true
        BarCode5Button.isHidden = true
        BarCode6Button.isHidden = true
        BarCode7Button.isHidden = true
        
        appDelegate.godex.debug(select: 0)
        // Do any additional setup after loading the view, typically from a nib.
    }


    override func viewWillAppear(_ animated: Bool) {
//          case .WiFi
        NotificationCenter.default.addObserver(self, selector: #selector(self.connect), name: NSNotification.Name(rawValue: appDelegate.godex.WiFiNotificationConnect), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.read), name: NSNotification.Name(rawValue: appDelegate.godex.WiFiNotificationRead), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.write), name: NSNotification.Name(rawValue: appDelegate.godex.WiFiNotificationWrite), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.wifidisconnected), name: NSNotification.Name(rawValue: appDelegate.godex.WiFiNotificationDisonnect), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.err), name: NSNotification.Name(rawValue: appDelegate.godex.WiFiNotificationError), object: nil)
        
//            case .BLE:
        NotificationCenter.default.addObserver(self, selector: #selector(self.BLEconnect), name: NSNotification.Name(rawValue: appDelegate.godex.BLENotificationConnect), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.BLEread), name: NSNotification.Name(rawValue: appDelegate.godex.BLENotificationRead), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.BLEDisconnect), name: NSNotification.Name(rawValue: appDelegate.godex.BLENotificationDisconnect), object: nil)
        
    }
    
    @objc func connect() {
        Font1Button.isHidden = false
        Font2Button.isHidden = false
        Font3Button.isHidden = false
        Font4Button.isHidden = false
        ImageButton.isHidden = false
        
        BarCode1Button.isHidden = false
        BarCode2Button.isHidden = false
        BarCode3Button.isHidden = false
        BarCode4Button.isHidden = false
        BarCode5Button.isHidden = false
        BarCode6Button.isHidden = false
        BarCode7Button.isHidden = false
    }
    
    @objc func err() {

    }
    
    @objc func BLEconnect() {
        Font1Button.isHidden = false
        Font2Button.isHidden = false
        Font3Button.isHidden = false
        Font4Button.isHidden = false
        ImageButton.isHidden = false
        
        BarCode1Button.isHidden = false
        BarCode2Button.isHidden = false
        BarCode3Button.isHidden = false
        BarCode4Button.isHidden = false
        BarCode5Button.isHidden = false
        BarCode6Button.isHidden = false
        BarCode7Button.isHidden = false
    }
    
    @objc func BLEread() {
        let string = appDelegate.godex.read()
        
        outputMes.text = outputMes.text + string!
        
        //資料進來，自動將textview滾到最下面
        let range = NSMakeRange(self.outputMes.text.characters.count - 1, 0)
        self.outputMes.scrollRangeToVisible(range)
    }
    
    @objc func BLEDisconnect() {
        let alertController = UIAlertController(title: cs_string, message: BLEdisconnect_string, preferredStyle: .alert)
        let cancel = UIAlertAction(title: OK, style: .cancel, handler: { (action) in
           _ = self.navigationController?.popToRootViewController(animated: true)
        })
        
        alertController.addAction(cancel)
        self.present(alertController, animated: true, completion: nil)
        
        Font1Button.isHidden = true
        Font2Button.isHidden = true
        Font3Button.isHidden = true
        Font4Button.isHidden = true
        ImageButton.isHidden = true
        
        BarCode1Button.isHidden = true
        BarCode2Button.isHidden = true
        BarCode3Button.isHidden = true
        BarCode4Button.isHidden = true
        BarCode5Button.isHidden = true
        BarCode6Button.isHidden = true
        BarCode7Button.isHidden = true
    }
    
    @objc func read(_ notification: Notification) {
        let string = appDelegate.godex.read()
        
        outputMes.text = outputMes.text + string!
        
        //資料進來，自動將textview滾到最下面
        let range = NSMakeRange(self.outputMes.text.characters.count - 1, 0)
        self.outputMes.scrollRangeToVisible(range)
    }

    
    @objc func write(_ notification: Notification) {
           appDelegate.godex.wifiExcuteRead()
    }
    
    @objc func wifidisconnected(_ notification: Notification) {
        Font1Button.isHidden = true
        Font2Button.isHidden = true
        Font3Button.isHidden = true
        Font4Button.isHidden = true
        ImageButton.isHidden = true
        
        BarCode1Button.isHidden = true
        BarCode2Button.isHidden = true
        BarCode3Button.isHidden = true
        BarCode4Button.isHidden = true
        BarCode5Button.isHidden = true
        BarCode6Button.isHidden = true
        BarCode7Button.isHidden = true
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
    }

    @IBAction func AddBLEConnect(_ sender: Any) {
        
    }

    
    @IBAction func AddWiFiConnect(_ sender: Any) {
    
        var alertController = UIAlertController(title: "Connect Printer", message: "Please input IP/Port", preferredStyle: UIAlertController.Style.alert)

        
        alertController.addTextField {
            (textField: UITextField!) -> Void in
            textField.placeholder = "IP"
            textField.text = "192.168.102.143"
        }
        alertController.addTextField {
            (textField: UITextField!) -> Void in
            textField.placeholder = "Port"
            textField.text = "9100"
//            textField.secureTextEntry = true
        }
        self.present(alertController, animated: true, completion: nil)
        
        var cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: {
            (action: UIAlertAction!) -> Void in
            self.appDelegate.godex.close()
            
            self.Font1Button.isHidden = true
            self.Font2Button.isHidden = true
            self.Font3Button.isHidden = true
            self.Font4Button.isHidden = true
            self.ImageButton.isHidden = true
            
            self.BarCode1Button.isHidden = true
            self.BarCode2Button.isHidden = true
            self.BarCode3Button.isHidden = true
            self.BarCode4Button.isHidden = true
            self.BarCode5Button.isHidden = true
            self.BarCode6Button.isHidden = true
            self.BarCode7Button.isHidden = true
        
        })


        var okAction = UIAlertAction(title: "Connect", style: .default) {
            (action: UIAlertAction!) -> Void in
//            var IP = (alertController.textFields?.first)! as UITextField
//            var Port = (alertController.textFields?.last)! as UITextField
            let IP = alertController.textFields!.first!.text!
            let Port = alertController.textFields!.last!.text!
            
            var res = self.appDelegate.godex.openport(address: IP, port: UInt16(Port)!)
//            print("res = \(res)")
            
        }
        
        alertController.addAction(okAction)
        alertController.addAction(cancelAction)
        
    }

    //--------------font button function-------------------------

    @IBAction func PrintDownloadFont(_ sender: Any) {
        appDelegate.godex.sendCommand(Command:"^Q100,0")
        
        appDelegate.godex.Downloadfont_TextOut(FontID: "A",PosX:100,PosY:100,Mul_X: 10, Mul_Y: 10, SpaceChar: 0, RotationSytle: .Degres_0, option: "BI", data: "Godex")
    }
    
    @IBAction func PrintTrueTypeFont(_ sender: Any) {
        appDelegate.godex.sendCommand(Command:"^Q50,0")
        
        appDelegate.godex.TrueTypeFont_TextOut(FontID: "A",PosX:100,PosY: 100, Font_W: 300, Font_H: 300, SpaceChar: 0, RotationSytle: .Degres_0, option:"BI", TTFTable: "A", data: "Godex")

    }
    
    @IBAction func PrintTextDownload(_ sender: Any) {
        appDelegate.godex.setup(width: 100, height: 50, dark: 16, speed: 4, mode: .PlainPaper, gap: 0, top: 0)
        
        appDelegate.godex.ecTextDownload(Font_Size: 30, RotationStyle: .Degres_180, Option: .Bold,.Italic, text: "科誠電子Godex")

//        appDelegate.godex.ecTextDownload(Font_Size: 30, RotationStyle: .Degres_0, Option: .None, text: "ffffffff")
        
//        appDelegate.godex.ecTextDownload(Font_Size: 60, RotationStyle: .Degres_0, Option: .None, text: "ffffffff")

        appDelegate.godex.ecTextDownload(Font_Size: 30, RotationStyle: .Degres_0, Option: .None, text: "ffffffff")
        
        
        appDelegate.godex.ecTextDownload(FontName: "ArialMT", PosX: 100, PosY: 100, Font_Size: 50, SpaceChar: 0, RotationStyle: .Degres_0, Option: .None, text: "ABC123Test!@#$%^&*(")
    }
    
    
    @IBAction func PrintInternalFont(_ sender: Any) {
        
        appDelegate.godex.setup(width: 100, height: 80, dark: 10, speed: 6, mode: .PlainPaper, gap: 0, top: 0)

        appDelegate.godex.InternalFont_TextOut(FontID: .Type_Z1 ,PosX: 0,PosY:0, Mul_X: 4, Mul_Y: 4, SpaceChar: 0, RotationSytle: .Degres_0,option: "I", data: "科誠電子Godex",Encoding: String.Encoding.Big5)
        
        appDelegate.godex.InternalFont_TextOut(FontID: .Type_Z1 ,PosX: 100,PosY:100, Mul_X: 4, Mul_Y: 4, SpaceChar: 0, RotationSytle: .Degres_90,option: "B", data: "科誠電子Godex",Encoding: String.Encoding.Big5)
        
        appDelegate.godex.InternalFont_TextOut(FontID: .Type_Z1 ,PosX: 800,PosY:800, Mul_X: 4, Mul_Y: 4, SpaceChar: 0, RotationSytle: .Degres_180,option: "IB", data: "科誠電子Godex",Encoding: String.Encoding.Big5)
        
        appDelegate.godex.InternalFont_TextOut(FontID: .Type_Z1 ,PosX: 800,PosY:800, Mul_X: 4, Mul_Y: 4, SpaceChar: 0, RotationSytle: .Degres_270,option: "R", data: "科誠電子Godex",Encoding: String.Encoding.Big5)
        
        
        //需要Ｚ3的空間下載日文字體
        appDelegate.godex.InternalFont_TextOut(FontID: .Type_Z3 ,PosX: 100,PosY:100, Mul_X: 4, Mul_Y: 4, SpaceChar: 0, RotationSytle: .vDegress_0,option: "I", data: "ありがとうございます",Encoding: String.Encoding.SJIS)
        
        
        //須在Z4的空間下載韓文字體
        appDelegate.godex.InternalFont_TextOut(FontID: .Type_Z4 ,PosX: 1000,PosY:1000, Mul_X: 4, Mul_Y: 4, SpaceChar: 0, RotationSytle: .vDegress_90,option: "B", data: "안녕하세요.",Encoding: String.Encoding.EUC_KR)
//
        //須在Z2的空間下載簡體字體
        appDelegate.godex.InternalFont_TextOut(FontID: .Type_Z2 ,PosX: 1000,PosY:1000, Mul_X: 4, Mul_Y: 4, SpaceChar: 0, RotationSytle: .vDegress_180,option: "IB", data: "科诚电子Godex",Encoding: String.Encoding.GB2312)
        
        
        appDelegate.godex.InternalFont_TextOut(FontID: .Type_Z1 ,PosX: 100,PosY:100, Mul_X: 4, Mul_Y: 4, SpaceChar: 0, RotationSytle: .vDegress_270,option: "R", data: "科誠電子Godex",Encoding: String.Encoding.Big5)
        
    
    }
    
    //--------------image button function-------------------------
    @IBAction func PrintImage(_ sender: Any) {
        let testImage = UIImage(named:"testImage")!
        self.appDelegate.godex.sendCommand(Command:"^Q50,0")
        self.appDelegate.godex.putimage(image: testImage)
        
        self.appDelegate.godex.sendCommand(Command:"^Q100,0")
        let testImage1 = UIImage(named:"testImage1")!
        self.appDelegate.godex.putimage(image: testImage1)
        
        self.appDelegate.godex.sendCommand(Command:"^Q220,0")
        let testImage2 = UIImage(named:"testImage2")!
        self.appDelegate.godex.putimage(image: testImage2)
    }
    
    
    //--------------barcode button function-------------------------
    @IBAction func Print1DBarCode(_ sender: Any) {
        appDelegate.godex.sendCommand(Command:"^Q30,0")
        
        appDelegate.godex.Bar_1D(Type: .Codabar, Narrow: 5, Width: 20, Height: 100, Rotation: .Degres_0, Readable: .Readable_Above_Center, Data: "12345567")
        
         appDelegate.godex.Bar_1D(Type: .Code39_STD, Narrow: 5, Width: 20, Height: 100, Rotation: .Degres_0, Readable: .Readable_Off, Data: "12345567")
        
        appDelegate.godex.Bar_1D(Type: .Logmars, PosX:600,PosY:100,Narrow: 5, Width: 20, Height: 50, Rotation: .Degres_180, Readable: .Readable_Below_Center, Data: "ABC123")
        
        appDelegate.godex.Bar_1D(Type: .I2of5, PosX:300,PosY:100,Narrow: 5, Width: 30, Height: 50, Rotation: .Degres_0, Readable: .Readable_Below_Center, Data: "1234")
    }
    
    @IBAction func PrintGS1BarCode(_ sender: Any) {
        appDelegate.godex.sendCommand(Command:"^Q30,0")
        
        appDelegate.godex.Bar_GS1Databar(Type: .Omnidirectional, Narrow: 10, Segment: 15, Rotation: .Degres_0, Readable: .Readable_Below_Center, Data: "123456")
        
        appDelegate.godex.Bar_GS1Databar(Type: .Truncated,PosX: 600,PosY:200, Narrow: 10, Segment: 15, Rotation: .Degres_180, Readable: .Readable_Above_Right, Data: "123456")
        
    }
    
    
    @IBAction func PrintPDF147(_ sender: Any) {
        appDelegate.godex.sendCommand(Command:"^Q30,0")
        
        appDelegate.godex.Bar_PDF147(Width: 20, Height: 50, Row: 0, Col: 0, ErrLevel: 7, Rotation: .Degres_0, Data: "Godex123ABC!@#$%")
        
    }
    
    
    @IBAction func PrintMaxicode(_ sender: Any) {
        appDelegate.godex.sendCommand(Command:"^Q30,0")
        
        appDelegate.godex.Bar_Maxicode(SymbolNo: 8, SetNo: 8, Mode: .US, CountryCode: 808, Class: 008, Rotation: .Degres_0, Data: "Godex123")
        

         appDelegate.godex.Bar_Maxicode(PosX:500,PosY:100,SymbolNo: 3, SetNo: 3, Mode: .US, CountryCode: 808, Class: 008, Rotation: .Degres_90, Data: "Godex123")
        
    }
    
    @IBAction func PrintDataMatrix(_ sender: Any) {
        appDelegate.godex.sendCommand(Command:"^Q30,0")
        
        appDelegate.godex.Bar_DataMatrix(Enlarge: 30, Rotation: .Degres_0, Data: "Godex123ABC")
        
        appDelegate.godex.Bar_DataMatrix(PosX:200,PosY:200,Enlarge: 20, Rotation: .Degres_270, Data: "zzxjep34kn")
        
        
        appDelegate.godex.Bar_DataMatrix(PosX:400 ,PosY:400,Enlarge: 20, Rotation: .Degres_0, Data: "1234dadf3")
    }
    
        @IBAction func PrintQRCode(_ sender: Any) {
            
        appDelegate.godex.sendCommand(Command:"^Q30,0")
            
        appDelegate.godex.Bar_QRCode(Mode: .Numerical, Type: .Model1_Original, ErrLevel: .Medium, Mask: 8, Mul: 7, Rotation: .Degres_0, Data: "12345678")
            
        appDelegate.godex.Bar_QRCode(PosX:200,PosY:200,Mode: .EightBit, Type: .Model2_Enhance, ErrLevel: .Medium, Mask: 8, Mul: 7, Rotation: .Degres_270, Data: "Godex123")
        appDelegate.godex.Bar_QRCode(PosX:300,PosY:200,Mode: .EightBit, Type: .Micro_QRcode, ErrLevel: .Medium, Mask: 0, Mul: 7, Rotation: .Degres_180, Data: "Godex123")
    }
    
    @IBAction func PrintAztec(_ sender: Any) {
        appDelegate.godex.sendCommand(Command:"^Q30,0")
        
        appDelegate.godex.Bar_Aztec(Rotation: .Degres_0, Mul: 10, ECICs: .Contains_ECICs, Type: 0, MenuSymbol: .Contains_Symbol, Data: "Godex123")
    }
    
    
    @IBAction func submit(_ sender: UIBarButtonItem) {
        appDelegate.godex.debug(select: 1)
        appDelegate.godex.sendCommand(Command: inputMes.text!)
        print("text = \(inputMes.text)")
        
        outputMes.text = ""
    }
}

